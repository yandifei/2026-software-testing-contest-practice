package net.mooctest.permission;

public enum ResourceType {
    EMPLOYEE_PROFILE,
    PAYROLL,
    EXPENSE_CLAIM,
    LEAVE_REQUEST,
    ATTENDANCE_RECORD,
    CONTRACT,
    AUDIT_LOG,
    SYSTEM_CONFIGURATION,
    PUBLIC_DOCUMENT
}
