package net.mooctest.expense;

public enum ExpenseCategory {
    AIRFARE,
    HOTEL,
    MEAL,
    LOCAL_TRANSPORT,
    OFFICE_SUPPLIES,
    CLIENT_ENTERTAINMENT,
    TRAINING,
    SOFTWARE,
    COMMUNICATION,
    MEDICAL,
    OTHER
}
