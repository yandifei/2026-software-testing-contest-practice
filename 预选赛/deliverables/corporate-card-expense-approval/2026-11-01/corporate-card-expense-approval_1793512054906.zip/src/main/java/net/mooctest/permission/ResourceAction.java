package net.mooctest.permission;

public enum ResourceAction {
    VIEW,
    CREATE,
    UPDATE,
    DELETE,
    APPROVE,
    EXPORT,
    SHARE,
    ARCHIVE,
    RESTORE
}
