package net.mooctest.workflow;

public enum ApprovalDecision {
    APPROVE,
    REJECT,
    RETURN,
    ABSTAIN
}
