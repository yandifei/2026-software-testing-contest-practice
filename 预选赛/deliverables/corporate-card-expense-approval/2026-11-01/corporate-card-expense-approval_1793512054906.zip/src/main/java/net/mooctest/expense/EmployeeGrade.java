package net.mooctest.expense;

public enum EmployeeGrade {
    INTERN,
    STAFF,
    SENIOR,
    MANAGER,
    DIRECTOR,
    EXECUTIVE
}
