package net.mooctest.expense;

public enum ExpenseApprovalTier {
    AUTO_APPROVED,
    LINE_MANAGER,
    DEPARTMENT_HEAD,
    FINANCE,
    FINANCE_DIRECTOR,
    CHIEF_FINANCIAL_OFFICER
}
