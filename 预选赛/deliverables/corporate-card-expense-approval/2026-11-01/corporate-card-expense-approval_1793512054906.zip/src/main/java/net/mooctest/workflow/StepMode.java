package net.mooctest.workflow;

public enum StepMode {
    ANY_ONE,
    MAJORITY,
    UNANIMOUS,
    REQUIRED_COUNT
}
