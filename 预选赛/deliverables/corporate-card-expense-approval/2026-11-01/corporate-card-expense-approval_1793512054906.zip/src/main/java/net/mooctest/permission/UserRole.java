package net.mooctest.permission;

public enum UserRole {
    EMPLOYEE,
    TEAM_LEAD,
    DEPARTMENT_MANAGER,
    HUMAN_RESOURCES,
    FINANCE,
    AUDITOR,
    SYSTEM_ADMINISTRATOR,
    GUEST
}
