package net.mooctest.workflow;

public enum WorkflowState {
    PENDING,
    IN_PROGRESS,
    APPROVED,
    REJECTED,
    RETURNED,
    WITHDRAWN,
    CANCELLED,
    EXPIRED
}
