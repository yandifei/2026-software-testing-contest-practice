package net.mooctest.expense;

public enum ReceiptType {
    TAX_INVOICE,
    STANDARD_RECEIPT,
    ELECTRONIC_RECEIPT,
    BANK_STATEMENT,
    NONE
}
