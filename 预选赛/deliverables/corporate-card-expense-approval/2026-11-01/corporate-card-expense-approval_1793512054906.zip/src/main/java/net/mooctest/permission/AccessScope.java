package net.mooctest.permission;

public enum AccessScope {
    OWN,
    TEAM,
    DEPARTMENT,
    ORGANIZATION
}
