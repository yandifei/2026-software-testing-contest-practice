package net.mooctest.expense;

public enum PaymentMethod {
    PERSONAL_CARD,
    CORPORATE_CARD,
    CASH,
    BANK_TRANSFER,
    DIGITAL_WALLET
}
