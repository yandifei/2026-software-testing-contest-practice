# 从项目到提交的操作流程

## 0. 开局三件事（2026-11 起前置）

1. **读权重**：`GET /api/contests/{id}` → `problems[].scoringWeights`。拿不到就按 mutation / branch / method / statement 各 25 的默认口径推进。详见 [评分口径与提交](scoring-and-submission.md)。
2. **读题包说明**：优先读题目附件里的 `开发者测试比赛要求.md`（或同名说明），确认测试文件**固定路径与文件名**（2026 省赛要求 `src/test/java/net/mooctest/StudentTest.java`，不是"任意 xxxTest"）、ZIP 首层结构、target 必须包含哪些报告。
3. **建工作区**：原始题包只读；开发副本独立；`_baseline`（基线/快照/证明）、`_snapshot`（定时快照）、`_tools`（脚本）分离。

## 1. 打开项目与保存基线

1. 默认当前目录及其所属仓库为工作区，用户另有指定则使用指定目录。读取适用的 AGENTS.md、说明、示例和 POM。
2. 比对页面工程名、附件名、包名与源码，避免混淆赛题。保留原始题包（ZIP 与 SHA-256）。
3. 执行 `java -version`、`mvn -version`，**两者都要看**：Maven 用 `JAVA_HOME`，与 `PATH` 里的 `java` 可能不是一个版本（2026 省赛实测系统 JAVA_HOME 指向 Java 8，而项目要求 21）。不一致时显式设置 `JAVA_HOME` 并把其 `bin` 放 `PATH` 首位，不改系统变量。
4. 生成基线清单：`python scripts/baseline.py <项目> _baseline/<题>.json`（含 `src/main` + `pom.xml` 全部文件的 SHA-256）。
5. 识别旧报告、多测试类、被禁用测试、插件与依赖。是否执行基线测试取决于本次运行轮数约束，不先跑再确认。

## 2. 按权重排优先级写测试

| 顺序 | 目标 | 具体动作 |
| --- | --- | --- |
| 1 | **METHOD 覆盖** | 列出每个类的全部方法（含重载、构造器、枚举、匿名内部类 `apply/run`），每个方法至少调用一次；空包优先补（引擎/工具类常是最大空白） |
| 2 | **LINE/语句** | 直路径、`else`/`default`、异常构造器、record 访问器、`toString/equals/hashCode` |
| 3 | **BRANCH** | `python scripts/branch_gaps.py <jacoco.xml> 25 1` 列出"类.方法 + 缺口数"，逐条补短路两侧/边界两侧/switch 常量 |
| 4 | **变异杀死** | `python scripts/pit_robust.py <mutations.xml> classes` 看存活分布，按算子决定攻击手法 |

- 单一测试文件、类名与文件名一致、UTF-8、题包指定的 JUnit；全部测试集中在题包要求的文件里（2026 省赛为 `StudentTest.java`）。
- 断言写在**可观察面**上：返回值内容、集合内容与顺序、异常类型 + 消息原文、`BigDecimal.toString()/scale()`、对象同一性、状态转移；只断言"不抛异常/布尔为真"几乎杀不掉变异。
- 疑似业务缺陷单独记录（依据/复现/实际结果），不改源码。

## 3. 运行与分析（一次只跑一个构建）

```powershell
$env:JAVA_HOME = "<JDK21 目录>"; $env:Path = "$env:JAVA_HOME\bin;$env:Path"
mvn -B clean test                                   # JUnit + JaCoCo（report 在 target/site/jacoco）
mvn -B org.pitest:pitest-maven:mutationCoverage     # 必须先 test；直接 goal 不编译
python scripts/jacoco_report.py target/site/jacoco/jacoco.xml 0
python scripts/branch_gaps.py target/site/jacoco/jacoco.xml 25 1
python scripts/pit_robust.py target/pit-reports/mutations.xml classes
Copy-Item target/pit-reports/mutations.xml _baseline/<题>-pit-<hhmm>.xml
```

硬规则：

- **同一个 `target` 目录同一时刻只能有一个 `mvn`**；多执行者各自独立副本（见 [多执行者并行与合并](multi-agent-integration.md)）。
- PIT 跑完**立刻**复制快照，后续只读快照；报告"条数 ≠ 期望分母"一律重跑（拼接/半写报告的真实事故见 `error-prevention.md` §16）。
- `mvn clean` 因文件被占用失败时改 `mvn -B test`（不 clean），不要反复硬撞。
- 每轮记录测试文件哈希、命令、时间、退出码、报告路径。

| 检查 | 证据 |
| --- | --- |
| 测试发现和通过 | Surefire 汇总及 `target/surefire-reports`；失败/错误为 0 |
| 方法覆盖 | `jacoco.xml` `METHOD` counter |
| 语句/行覆盖 | `jacoco.xml` `LINE`（注明是 LINE 代理，不称语句覆盖） |
| 分支覆盖 | `jacoco.xml` `BRANCH` counter；缺口按类+方法列 |
| 变异杀死 | `mutations.xml` 各状态分别计数（KILLED/SURVIVED/NO_COVERAGE/TIMED_OUT/RUN_ERROR），禁止减法推导 |
| 版本一致 | 报告时间、测试文件哈希、当轮命令一一对应 |
| 修改边界 | `python scripts/verify_baseline.py <项目> _baseline/<题>.json` → 必须 OK |

## 4. 并行补测与合并（需要时）

- 大空白包（如内嵌表达式引擎）可拆两半给两个专项执行者，各自独立副本、只新增 `XxxProbeTest.java`。
- 合并为 `@Nested` 内部类；用「基线备份 + 各 probe」**幂等重建**，不要在已合并文件上继续插；合并后必须编译 + 重跑全量 PIT。
- 细节与脚本坑见 [多执行者并行与合并](multi-agent-integration.md)。

## 5. 打包与验收

```powershell
python scripts/verify_baseline.py <项目> _baseline/<题>.json      # 源码/POM 未动
python scripts/package_project.py <项目> deliverables/<题>/<题>.zip
# ZIP 校验：首层 pom.xml / 说明.md / src / target；target 内有 pit-reports 与 site/jacoco；
#           src/test 只有一个测试文件；ZIP 内测试文件与独立交付的 .java 字节一致
```

两个必需产出：

1. 测试 `.java`：UTF-8，与工程内文件字节一致，满足页面 ≤2.0 MB；
2. 完整项目 ZIP：≤20.0 MB，含原 POM、`src/main`、单测试文件、必要配置/资源、执行后的 `target`（含 `pit-reports/index.html` 与 `site/jacoco/index.html`）。

排除项：`.git`、`.idea`、`.vscode`、`*.iml`、`out.txt`/`*.log`（IDE 与构建残留，2026 省赛实际在工程根上出现过 `out.txt` 与 `.idea`）、其它题目、编辑器缓存、嵌套提交包。注意不要只打 `git archive`（会漏掉被忽略的 `target`）。

ZIP 外写交付记录（用 [交付记录模板](../assets/delivery-record.md)）：文件名、相对路径、字节数、SHA-256、命令、通过数、四类指标分子/分母、报告路径、基线比较、提交回执。

## 6. 浏览器上传与回执

本地材料验收后按 [浏览器提交](browser-submission.md) 与 [评分口径与提交](scoring-and-submission.md) §3–§5 操作：

- "选择文件"只挂本地状态，点"提交/重新提交"才 presign → PUT → confirm，所以可以"先附文件、核对文件名、再提交"；
- 提交后读 `/api/contests/{id}` 的 `submittedAt` 与 `submittedFiles[].fileSize`，与本地交付件逐字节大小比对，并保存页面回执文案；
- **判分以最后一次提交为准**：可以先用当前最好版本保底提交，再迭代重交；多工具并行时提醒用户确认由哪个会话收尾。
