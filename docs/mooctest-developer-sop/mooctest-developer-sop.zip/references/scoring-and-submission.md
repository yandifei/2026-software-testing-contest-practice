# 平台评分口径、题包下载与提交回执（2026 赛制实测）

> 核验来源：2026-11-15 省赛（mooctest contest 35）当场页面 + 平台前端 API 实测。前端是 Vue SPA，页面文案不写权重，**权重只在 API 返回里**，因此"看页面规则"不足以确定优化方向。

## 1. 先读评分权重，再决定优化方向

```text
GET /api/contests/{contestId}
→ data.problems[].scoringWeights = {
      "mutation": 25,
      "coverage_branch": 25,
      "coverage_method": 25,
      "coverage_statement": 25
  }
   data.problems[].scoreProportion  // 该题占赛事总分的比例（本题 50）
```

2026 省赛实测：两题各占 50%，每题内部 **变异 25 + 分支 25 + 方法 25 + 语句 25**。

这直接改变了优化顺序（旧版 SOP 只盯"分支 40% / 变异 30%"）：

| 优先级 | 目标 | 做法 | 2026 省赛实测收益 |
| --- | --- | --- | --- |
| 1 | METHOD 覆盖 | 把每个类每个方法（含重载、构造器、枚举、匿名内部类的 `apply/run`）至少调用一次 | Math 的 `expression.engine` 从 0/511 起步，一次专项补齐 305 个方法 |
| 2 | LINE/语句覆盖 | 直路径、`else`/`default`、异常构造器、record 访问器 | 与 method 同批完成 |
| 3 | BRANCH | 短路两侧、边界两侧、switch 每个常量 | Math +104 分支、Card +78 分支 |
| 4 | 变异杀死 | 前 3 项做完后的剩余存活项 | 最后两轮 +10 / +9 |

**纪律**：报告必须四项分开写（mutation / branch / method / statement），并注明 statement 用什么代理（JaCoCo LINE 或 Clover），不得用 LINE 冒充语句。

## 2. 题包下载（不要点按钮猜 URL）

```text
GET /api/contests/{contestId}                 → data.problems[].fileList: ["problems/135/card-approval_...zip"]
GET /api/contests/{contestId}/problems/{pid}/files/url?objectKey=<objectKey>
→ data.url = OSS 预签名 URL（带 Expires/Signature，过期时间约 1 天）
```

- 预签名 URL 可脱离浏览器会话用 HTTP 直接下载，不必依赖浏览器下载目录。
- **ZIP 条目名常见 GBK 编码**：用 .NET/Python 默认 UTF-8 解压会得到 `�����߲��Ա���Ҫ��.md` 这类乱码名。用 `scripts/extract_zip.py`（cp437 → gbk 回退链）解包，能还原 `开发者测试比赛要求.md`。
- 解包前校验条目不含 `../`、绝对路径、盘符；先看是否有顶层工程目录，不要假设。

## 3. 提交的真实流程（前端 API）

```text
POST /contests/{cid}/problems/{pid}/submit/presign
     {"files":[{"filename","fileSize","contentType","ruleIndex"}, ...]}
→ data.files[i] = { objectKey, uploadUrl, contentType }
→ 对每个 uploadUrl 直接 PUT 文件字节
POST /contests/{cid}/problems/{pid}/submit/confirm
     {"files":[{"objectKey","fileSize","filename","ruleIndex"}, ...]}
```

关键结论（2026-11-15 实测 + 前端 bundle 静态分析）：

1. **"选择文件"只把 File 挂在本地组件状态里，不发请求**；点"重新提交/提交"才 presign → PUT → confirm。所以"先附上文件、核对文件名、再提交"是安全操作，不会产生半成品提交。
2. 提交必须有**全部**文件（两题都是 java + zip 两个槽），少一个按钮就 disabled。
3. 提交成功后按钮文案从"提交"变为"重新提交"，页面出现 `已提交: StudentTest.java 等2个文件 于 2026-11-15 16:25`。
4. **判分以最后一次提交为准**（题包说明明写），所以可以"先保底交一版，再迭代重交"。没有发现提交次数限制，但仍以当场页面为准。

## 4. 回执核验（不能只看"点过按钮"）

```text
GET /api/contests/{contestId}
→ data.problems[].submittedAt
   data.problems[].submittedFiles[] = { fileName, fileSize, fileKey }
```

核验三步：

1. `submittedAt` 是你刚操作的时间；
2. `submittedFiles[].fileSize` 与你本地交付件**逐字节大小一致**（这是最强的一致性证据；`/submissions/{id}/files/url` 接口对 participant 不一定可用，实测返回 400/404，不要卡在这里）；
3. 页面文案出现"已提交 … 于 HH:mm"。

## 5. 多会话/多工具抢同一个浏览器与同一份提交

2026-11-15 实际发生：**另一个 AI 工具会话在同一个共享侧边浏览器里，于 14:24/14:25 提交了它自己的版本**（文件大小 236KB/284KB，与本会话产出不同）。因为"最后一次为准"，它会把你的成绩顶掉。

处理方式：

- 每次提交前先读 `submittedAt` 与文件大小，确认当前平台上是谁的版本；
- 交付前**最后再提交一次**，并在汇报里写明"当前平台归属本会话版本"；
- 若用户在多工具并行跑同一赛事，明确提示"最终以最后一次提交为准，请确认由哪个会话收尾"。

## 6. 页面时间陷阱

- 比赛未开始时页面只显示"比赛暂未开始"，题目区不渲染；**开始时刷新即可**，不要反复登录。
- 倒计时"距离结束 N 小时"是向下取整，**不要用它推算截止**；以 `contestEnd`（API）与页面 `比赛时间` 文案为准。
