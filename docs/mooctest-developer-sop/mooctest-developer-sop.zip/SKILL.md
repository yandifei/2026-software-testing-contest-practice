---
name: mooctest-developer-sop
description: 为慕测软件测试大赛开发者赛项核对规则与评分权重、编写和验证 JUnit 测试（方法/语句/分支/变异四维）、打包交付并通过浏览器提交。适用于 Java 单元测试赛题、参赛材料检查与多执行者并行补测。
---

# 慕测开发者测试

以当前目录及其所属仓库为工作区，按用户指定题目和阶段完成任务。支持核对规则、编写测试、验证、打包或完整提交，不将局部请求扩大为提交。

## 开始执行

1. **先拿到评分口径。** 读 [评分口径与提交](references/scoring-and-submission.md) §1，从平台 API（如 `GET /api/contests/{id}`）取 `scoringWeights`。2026 省赛实测每题是"变异 25 / 分支 25 / 方法 25 / 语句 25"，**方法+语句占一半**；只盯分支与变异会把一半的分做丢。拿不到权重时按"方法 → 行 → 分支 → 变异"的顺序推进。
2. **打开浏览器、登录并下载题目。** 在 Codex（ChatGPT）、Claude、WorkBuddy 等 AI 编程工具提供的浏览器界面中，按 [登录、选赛与下载](references/browser-entry.md)进入慕测登录页，让用户自行输入凭证并登录；再进入比赛列表，滚动到底部查找目标比赛，点击进入并下载题目。已有登录态、比赛页或题包时复用，不重复登录或覆盖已有项目。只处理现有本地项目且不需要下载时，可直接进入下一步。
3. 读取 [赛事规则](references/competition-rules.md)，获取当前比赛页和下载题包要求，记录年份、阶段、题目、截止时间、代码边界、上传格式和大小。参考资料是带日期的规则快照，不能替代当场规则。
4. 以当前目录及仓库为工作区，解压并核对题包。读取适用的 AGENTS.md、项目说明、pom.xml 和示例测试。存在多个项目时，按题目、附件名与网页工程名匹配；无法唯一匹配才询问。路径从工作区解析，不预设盘符、用户名、IDE 或工具安装位置。
5. **通读 [防错方法论](references/error-prevention.md)。** 该清单记录本技能执行者历轮真实错误（输入值域穷举不全、变异语义靠记忆、下游顶包漏查、报告脏数据、并发冲突、权重误判、合并写坏文件、外部覆盖丢失成果等）；每轮开始与每次宣称"不可达/等价"前对照检查。
6. 按请求执行以下阶段；未限定轮数时，允许针对明确缺口迭代。用户限定次数时遵守，不额外先跑基线。


## 编写与验证

读取 [测试工作流](references/workflow.md)第 1–3 节。

### 使用 Superpowers 等测试技能

编写测试前，检查当前环境可用的技能并实际读取相关说明，优先结合 Superpowers 提高用例质量、分支覆盖率和变异杀死率：

- 开始工作时读取 `using-superpowers`，按其要求选择适用技能。
- 设计用例时使用测试质量指导，例如 `test-driven-development` 随附的 `writing-good-tests`，或可用的 `tdd` 技能：先说明每个测试应检出的错误，再设计独立预期值、边界矩阵、异常路径和状态断言。不得让被测代码同时计算预期值。
- 编译失败、测试失败、报告异常或指标出现意外缺口时，使用 `systematic-debugging`：先读取证据并定位原因，再提出单一假设、做最小修正并验证，避免盲目追加用例或反复重跑。
- 宣称通过、达到某个覆盖率或准备提交前，使用 `verification-before-completion`，以本轮实际执行和报告为依据。

技能可能以 `superpowers:` 前缀或无前缀提供，按当前技能目录发现，不写死安装路径，也不假设接收者已安装。相关技能不可用时，采用本技能自带的 [测试方法与故障处理](references/testing-methodology.md)，如实说明未加载外部技能，不阻断可完成的测试工作。

本赛事禁止修改生产代码，因此不执行 TDD 中修改或删除被测实现的步骤；对既有实现采用回归测试、独立参照与 PIT 验证断言敏感性。先依据 JaCoCo 找分支输入缺口，再依据 PIT 找断言缺口；每轮补测必须对应具体缺口或可区分变异。Superpowers 是执行方法，不保证百分比达到 100%，也不能改变赛事约束或统计口径。

### 执行要求

- 禁止修改、删除、替换或新增 `src/main/java/net/mooctest/` 下的被测源代码，也不得移动源文件、改变包名或通过生成步骤覆盖它们。其他被测源码及 `pom.xml` 同样保持原样，只编写允许的测试内容。执行前后对比源码文件清单及哈希（`scripts/verify_baseline.py`），出现差异时不得打包提交，先查明原因并恢复到可信题包基线。
- 测试文件位置与命名以题包说明为准（2026 省赛固定为 `src/test/java/net/mooctest/StudentTest.java`）；单一文件、类名与文件名一致、UTF-8、题包指定的 JUnit，不新增其它测试文件、不写 `main()`。
- **按权重的顺序写**：先让每个方法至少被调用一次（METHOD），再补语句/行，再补分支两侧，最后攻变异。断言必须落在可观察面（返回值内容、reasons 列表顺序、异常消息原文、`BigDecimal.toString()/scale()`、对象同一性），只断言布尔值会被同对象的其它规则"顶包"。
- 白盒手段按当场规则分层，并标注"真实输入可达"与"环境可达"：真实输入 → 反射直调私有/包私有方法 → mock record/enum 构造非法状态。若规则明确禁止"干预函数返回结果、使程序进入原实现无法到达的路径"（2026 省赛《作弊与违规说明》第 2 点），则**不得使用 `mockConstruction` / `mockStatic(MockedStatic)`**，也不得替换字节码、探测 mutant 身份、改报告或缩分母。
- 用原项目插件运行 JUnit、JaCoCo、PIT，核对测试发现数、成功状态与最终报告版本；**同一 target 目录同时只跑一个构建**，PIT 报告跑完立刻按时间戳复制快照。
- 分段并行生产测试时（见 [多执行者并行与合并](references/multi-agent-integration.md)）：段合并进主文件后**立即删除曾拷入 `src/test` 的独立副本**（残留旧编译产物会让 PIT 报"幽灵测试类"未过绿套件检查，防错 §23）；涉及共享静态组件的段自带注册表/缓存重置钩子，合并时不得删（防错 §24）；不确定的生产 API 语义先探针再写断言（防错 §25）。
- 区分方法、语句/行、分支覆盖和原始变异杀死率。有输入或断言依据才补测；等价变异记录证明，不改报告、不缩小分母凑满分。


## 指标冲刺与研究

用户要求提分、达到 100%，或历史报告声称存在等价/不可达缺口时，读取 [覆盖与变异研究](references/coverage-mutation-research.md)。逐项建立可达性、状态差异、传播与断言的证据链；先尝试用有效反例推翻历史等价结论，再记录真正不可达/等价项及未解决项。判定"不可达"之前必须先做**可达性攻击**（该文第 8–9 节）：从本地 PIT jar 反汇编变异语义、用字母/Unicode 数字字符（getNumericValue 无 35 上限）扩展输入值域、用下游异常消息与兜底逻辑找观察差、用 mockConstruction 让遮蔽者拒绝、用 record 构造态畸形值与 int/容量溢出构造反例、用对象同一性（assertSame/assertNotSame）与归一化前的 scale/toString 找身份差异、用 MockedStatic 打开必抛分支、用反射直调绕开上游归一化、用线程超时（< PIT 3s 上限）把死循环变异转成确定性失败；全部失败后才写路径证明。保持原统计分母，不能承诺所有题目都可实现 100%。口径注意：官方缺口文档统计"分母含全部变异、分子只计 KILLED、TIMED_OUT 为 0"，能转 KILLED 的 TIMED_OUT 必须转；PIT 覆盖只归属测试主线程，自增指令类变异无归属时如实记录为工具行为。最终残留项按官方文档模式逐项附等价性证明（行号+指令索引→变异后控制流→值域分析→下游兜底），证明本身就是交付物的一部分。

进一步受私有计数器、时钟或字段可观察性限制时，按用户授权与当场规则选择是否采用 [白盒补测](references/whitebox-research.md)。白盒手段按"真实输入可达"与"mock/反射环境可达"分别标注；Mockito mock record/mock 枚举/mockConstruction 均在题包自带依赖范围内，官方参考缺口文档认可其杀死数，但报告不把环境可达包装成真实链行为。本地实验与可上传版本分别注明；控制共享状态必须恢复，已证不可达或等价的局部逻辑不因使用反射而自动可测。

用户明确要求从头重做时，读取 [独立重做与新旧比较](references/independent-rebuild.md)，保留原最好版本，在独立目录重新设计，并按同一变异集合比较实际收益与回退。多会话/多工具并行产出过同一题的全量 PIT 报告时，先做**变异级跨会话对账**（[多执行者并行与合并](references/multi-agent-integration.md) §8）：按 (类,方法,行,描述) 四元组 join 出"他杀我活"清单，量化逐包差距并到最强会话的对应类里移植用例——比通读对方代码快一个数量级。

## 打包

读取 [测试工作流](references/workflow.md)第 5 节，使用 [交付记录模板](assets/delivery-record.md)填写结果。

生成独立 Java 文件和完整项目 ZIP，满足当前上传限制，保留要求的执行后 target。用 `scripts/package_project.py` 打包并自检（首层结构、`target/pit-reports/index.html`、`target/site/jacoco/index.html`、`src/test` 仅一个测试文件、ZIP 内测试文件与独立交付的 `.java` 字节一致），它默认排除 `.git/.idea/.vscode/*.iml/out.txt/*.log`。打包前后各跑一次 `scripts/verify_baseline.py`，确认 `src/main` 与 `pom.xml` 未被改动。交付记录留在 ZIP 外，不自动增加赛事附件。

对于 Research-Project-Management-System 练习题：将所有模块的测试方法集中于一个顶层测试类、一个 `xxxTest.java` 文件；完成验证后，将该题完整项目目录压缩为 ZIP。分别上传该 Java 文件和项目 ZIP，共两个文件。生产代码仍保持原来的多文件结构，不合并。具体依据和目录示例见 [Research 交付要求](references/competition-rules.md#research-交付要求)。

## 提交

用户要求提交对应题目时，读取 [浏览器提交](references/browser-submission.md) 与 [评分口径与提交](references/scoring-and-submission.md) §3–§5，确认赛事和题目，上传同一版本的材料并取得回执。评分未完成则标记评分中。

- "选择文件"只挂本地状态，点"提交/重新提交"才 presign → PUT → confirm；可以先附文件、核对文件名再提交，不会产生半成品提交。
- 提交后读 API 的 `submittedAt` 与 `submittedFiles[].fileSize`，与本地交付件逐字节大小比对，并保存页面回执文案（如"已提交 … 于 HH:mm"）。
- 判分以最后一次提交为准：可先用当前最好版本保底提交，再迭代重交；若平台上出现非本会话的版本（多工具共用侧边浏览器时会发生），先确认归属，收尾时再提交一次。

使用当前环境可用的浏览器控制工具，不预设固定插件。能力不可用时，完成本地可做阶段，交付材料并说明具体阻碍，不把准备完成称为提交成功。

## 验收与汇报

报告实际完成阶段、交付文件、通过数、**方法/行/分支/变异四类指标的分子分母**、报告依据、剩余问题及提交回执。本地指标与平台成绩分开。关键规则冲突、源码基线异常或材料无法满足容量时，保留成果并说明具体问题；没有新假设时不反复空跑或重复提交。

需要设计独立判定方法、合并历史测试，或处理覆盖报告/上传工具异常时，读取 [可复用测试方法与故障处理](references/testing-methodology.md)。需要拆成多执行者并行、或与其他会话的产出做变异级对账时，读 [多执行者并行与合并](references/multi-agent-integration.md)（probe 文件 → `@Nested` 合并、幂等重建、独立复核数字、§8 跨会话对账）。需要复盘整轮打法的实证时，读 [2026-11-15 省赛案例](references/case-2026-11-15-provincial.md)（§8 含 glm 执行线的指标对照与题包怪癖目录）。新增经验必须来自真实观察，写清症状、判断依据、恢复方式与适用边界，不将某台机器的路径或偶发错误固化为通用前提。`scripts/` 下的工具都是通用实现，直接调用，不要就地改写。

## 脚本清单

| 脚本 | 用途 |
| --- | --- |
| `scripts/extract_zip.py <zip> <dir>` | 解包并修复 GBK 条目名（cp437→gbk/gb18030/utf-8 回退链），拒绝越界条目 |
| `scripts/baseline.py <项目> <out.json>` | 生成 `src/main` + `pom.xml` 的 SHA-256 基线清单 |
| `scripts/verify_baseline.py <项目> <baseline.json>` | 校验源码/POM 未改、测试目录只有一个文件，异常时非 0 退出 |
| `scripts/package_project.py <项目> <out.zip>` | 打包并按赛题结构自检（首层、两套报告入口、单测试文件、字节一致、体积） |
| `scripts/jacoco_report.py <jacoco.xml> [N] [M]` | 输出 INSTRUCTION/LINE/BRANCH/METHOD/CLASS 与按类缺口，`M>0` 时列未覆盖方法 |
| `scripts/branch_gaps.py <jacoco.xml> [N] [1]` | 按"类.方法"列分支缺口，打分支阶段按收益排序用 |
| `scripts/pit_robust.py <mutations.xml> <summary\|classes\|list\|mutators>` | 容错解析 PIT 报告（可处理拼接/半写文件），逐状态计数并给出 KILLED 率 |
| `scripts/merge_engine.py <主文件> <probe文件> <out> [Nested类名]` | 把 probe 类体合并为主文件的 `@Nested` 内部类（字符串/注释感知的花括号配平、import 去重） |
| `scripts/replace_section.py <主文件> <最新段文件> <Nested容器类名>` | 执行者交付后又修订了段文件时，按容器类名**整体替换**该 `@Nested` 容器的类体（复用 merge_engine 的配平状态机）；替换后必须重跑 `mvn -B test` |
